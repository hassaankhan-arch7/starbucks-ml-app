# Starbucks Beverage Classifier (GitHub + Streamlit Community Cloud)

## Files in this repository
- `app.py` — corrected Streamlit application
- `starbucks.csv` — dataset loaded automatically by the app
- `requirements.txt` — Python dependencies

## Deploy
1. Upload these three files to the root of a GitHub repository.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose **Create app**.
4. Select your repository and branch.
5. Set **Main file path** to `app.py`.
6. Click **Deploy**.

## What was corrected
- Removed the Google Colab-only `/content/archive.zip` path.
- Reads `starbucks.csv` from the repository root; it also offers an optional CSV upload.
- Strips leading/trailing spaces from CSV column names.
- Cleans percentage/numeric nutrition columns before training.
- Uses Streamlit widgets instead of notebook-only `display()` calls.
- Handles missing values and rare classes more safely.
- Shows data previews, charts, model accuracy, classification report, and downloadable predictions/model.

Keep `starbucks.csv` in the same repository folder as `app.py`. The previously uploaded `.pkl` file is not required because this app trains the model when you click **Train model**.
